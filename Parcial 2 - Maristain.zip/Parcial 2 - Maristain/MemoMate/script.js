const API_ENDPOINT = 'https://66773665145714a1bd741cdf.mockapi.io/api/v1/MemoMate';
const SETTINGS_KEY = 'memomate-settings';

document.addEventListener('DOMContentLoaded', function() {
  const currentPage = document.location.pathname;
  loadTasks();

  // Formulario para nueva tarea
  const newTaskForm = document.getElementById('new-task-form');
  if (newTaskForm) {
    newTaskForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const name = document.getElementById('name').value;
      const textbox = document.getElementById('textbox').value;
      const status = document.getElementById('status').value;
      const createdAt = new Date().toISOString();
      const task = { name, textbox, status, createdAt };
      createTask(task);
    });
  }

  // Formulario para cambiar estado de tarea
  if (currentPage === '/change-status.html') {
    loadTasksForChangeStatus();
  }

  // Formulario para configuración
  const settingsForm = document.getElementById('settings-form');
  if (settingsForm) {
    settingsForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const language = document.getElementById('language').value;
      const rate = document.getElementById('rate').value;
      saveSettings({ language, rate });
    });
  }
});

function loadTasks() {
  fetch(API_ENDPOINT)
    .then(response => {
      if (!response.ok) {
        throw new Error('No se pudo cargar las tareas.');
      }
      return response.json();
    })
    .then(tasks => {
      // Ordenar las tareas por fecha de creación en orden descendente
      tasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      displayTasks(tasks);
    })
    .catch(error => console.error('Error al cargar tareas:', error));
}

function displayTasks(tasks) {
  const taskList = document.getElementById('task-list');
  taskList.innerHTML = '';
  tasks.forEach(task => {
    const taskCard = createTaskCard(task);
    taskList.appendChild(taskCard);
  });
}

function createTaskCard(task) {
  const card = document.createElement('div');
  card.classList.add('task-card');
  card.setAttribute('data-task-id', task.id);

  const cardContent = document.createElement('div');
  cardContent.classList.add('task-card-content');

  const title = document.createElement('h3');
  title.textContent = task.name;

  const detail = document.createElement('p');
  detail.textContent = task.textbox;

  const status = document.createElement('p');
  status.textContent = `Estado: ${task.status}`;

  cardContent.appendChild(title);
  cardContent.appendChild(detail);
  cardContent.appendChild(status);

  card.appendChild(cardContent);

  const currentPage = document.location.pathname;
  if (currentPage === '/change-status.html') {
    const changeStatusForm = document.createElement('form');
    changeStatusForm.innerHTML = `
      <label for="status-${task.id}">Cambiar Estado:</label>
      <select id="status-${task.id}" name="status">
        <option value="Pendiente" ${task.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
        <option value="En_progreso" ${task.status === 'En_progreso' ? 'selected' : ''}>En Progreso</option>
        <option value="Completada" ${task.status === 'Completada' ? 'selected' : ''}>Completada</option>
      </select>
      <button type="submit">Guardar Cambios</button>
      <input type="hidden" id="task-id-${task.id}" name="taskId" value="${task.id}">
    `;
    changeStatusForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const taskId = task.id;
      const newStatus = document.getElementById(`status-${task.id}`).value;
      updateTaskStatus(taskId, newStatus);
    });

    card.appendChild(changeStatusForm);
  } else {
    const editButton = document.createElement('button');
    editButton.textContent = 'Editar';
    editButton.addEventListener('click', function() {
      editTask(task);
    });

    card.appendChild(editButton);
  }

  const playButton = document.createElement('img');
  playButton.src = 'img/boton-de-play.png'; 
  playButton.alt = 'Reproducir';
  playButton.classList.add('play-button');
  playButton.addEventListener('click', function() {
    playTask(task);
  });

  card.appendChild(playButton);

   if (task.status.toLowerCase() === 'completada') {
    const completedAt = document.createElement('p');
    completedAt.textContent = `Completada el: ${new Date(task.updatedAt).toLocaleString()}`;
    card.appendChild(completedAt);
    card.classList.add('completed-task');

    const completedIcon = document.createElement('img');
    completedIcon.src = 'img/comprobado.png';
    completedIcon.alt = 'Completado';
    completedIcon.classList.add('completed-icon');
    card.appendChild(completedIcon);
  }

  return card;
}

function createTask(task) {
  fetch(API_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(task),
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Error al crear la tarea.');
      }
      return response.json();
    })
    .then(newTask => {
      console.log('Tarea creada correctamente:', newTask);
      loadTasks();
      document.getElementById('new-task-form').reset(); // Limpiar formulario
    })
    .catch(error => console.error('Error al crear tarea:', error));
}

function updateTaskStatus(taskId, status) {
  const updatedAt = new Date().toISOString();
  const updateData = { status };

  if (status.toLowerCase() === 'completada') {
    updateData.updatedAt = updatedAt;
  }

  fetch(`${API_ENDPOINT}/${taskId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updateData),
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Error al actualizar el estado de la tarea.');
      }
      return response.json();
    })
    .then(updatedTask => {
      console.log('Estado de la tarea actualizado:', updatedTask);
      loadTasks(); // Recargar las tareas actualizadas
    })
    .catch(error => console.error('Error al actualizar estado de tarea:', error));
}

function editTask(task) {
  const editForm = document.createElement('form');
  editForm.innerHTML = `
    <label for="name-${task.id}">Nombre:</label>
    <input type="text" id="name-${task.id}" name="name" value="${task.name}">
    
    <label for="textbox-${task.id}">Descripción:</label>
    <textarea id="textbox-${task.id}" name="textbox">${task.textbox}</textarea>
    
    <label for="status-${task.id}">Estado:</label>
    <select id="status-${task.id}" name="status">
      <option value="Pendiente" ${task.status === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
      <option value="En_progreso" ${task.status === 'En_progreso' ? 'selected' : ''}>En Progreso</option>
      <option value="Completada" ${task.status === 'Completada' ? 'selected' : ''}>Completada</option>
    </select>
    
    <button type="submit">Guardar Cambios</button>
  `;
  editForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById(`name-${task.id}`).value;
    const textbox = document.getElementById(`textbox-${task.id}`).value;
    const status = document.getElementById(`status-${task.id}`).value;
    updateTask(task.id, { name, textbox, status });
  });

  const taskCard = document.querySelector(`[data-task-id="${task.id}"] .task-card-content`);
  taskCard.innerHTML = '';
  taskCard.appendChild(editForm);
}

function updateTask(taskId, updatedFields) {
  fetch(`${API_ENDPOINT}/${taskId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updatedFields),
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Error al actualizar la tarea.');
      }
      return response.json();
    })
    .then(updatedTask => {
      console.log('Tarea actualizada:', updatedTask);
      loadTasks(); // Recargar las tareas actualizadas
    })
    .catch(error => console.error('Error al actualizar tarea:', error));
}

function saveSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function playTask(task) {
  const textToSpeech = task.textbox;
  const settings = JSON.parse(localStorage.getItem(SETTINGS_KEY)) || { language: 'es-ES', rate: 1 };
  const utterance = new SpeechSynthesisUtterance(textToSpeech);
  utterance.lang = settings.language;
  utterance.rate = parseFloat(settings.rate);
  speechSynthesis.speak(utterance);
}

function loadTasksForChangeStatus() {
  fetch(API_ENDPOINT)
    .then(response => {
      if (!response.ok) {
        throw new Error('No se pudo cargar las tareas.');
      }
      return response.json();
    })
    .then(tasks => {
      tasks.forEach(task => {
        const taskCard = createTaskCard(task);
        document.getElementById('task-list').appendChild(taskCard);
      });
    })
    .catch(error => console.error('Error al cargar tareas para cambiar estado:', error));
}